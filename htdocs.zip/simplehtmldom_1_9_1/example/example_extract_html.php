<?php
include_once('../simple_html_dom.php');

//echo file_get_html('http://www.google.com/')->plaintext;


//$html = file_get_html($link_figura);
// $nombre = $html;

$nombre = file_get_html('https://myfigurecollection.net/item/7223')->find('.headline',0)->plaintext;
//	echo file_get_html('https://myfigurecollection.net/item/7223')->find('img[alt='.$nombre.']',1)->outertext;
//	echo file_get_html('https://myfigurecollection.net/item/7223')->find('img[alt='.$nombre.']',0)->src;
//	echo file_get_html('https://myfigurecollection.net/item/7223')->find('img[alt='.$nombre.']',1)->src;
//echo file_get_html('https://myfigurecollection.net/item/7223')->find('.main',0)->innertext;

//echo file_get_html('https://myfigurecollection.net/item/7223')->find('.thumbnail',0)->src;
  preg_match('/\(([\s\S]+)\)/', $nombre, $output_array);
 $marca = $output_array[1];
 echo $output_array[1];
 echo $output_array[0];




$url = "https://static.myfigurecollection.net/pics/figure/big/7223.jpg";
  
// Use get_headers() function
$headers = @get_headers($url);
  
// Use condition to check the existence of URL
if($headers && strpos( $headers[0], '200')) {
    $status = "URL Exist";
}
else {
    $status = "URL Doesn't Exist";
}
  
// Display result
echo($status);










?>